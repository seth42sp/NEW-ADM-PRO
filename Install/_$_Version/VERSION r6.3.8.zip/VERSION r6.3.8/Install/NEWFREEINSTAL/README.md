﻿# NEWFREEINSTAL

* Sistema de tradução não vai funcionar devido a problema na api

apt-get update -y; apt-get upgrade -y; wget https://www.dropbox.com/s/qhftefty46hz51x/newfreeinstal?dl=0 && bash new*

-------------------------------------------------------------------------------

```
* SIN MINERIA! 
* SIN KEYS! 
* VERSION GRATUITA 
* SIN VIRUS TROJANO (BOTNET) 
* ARCHIVOS LIBERADOS (DECENCRIPTADOS)
```

```
☆ https://t.me/admmanagerfree ☆

```

**By: [  ⃘⃤꙰✰ ]**